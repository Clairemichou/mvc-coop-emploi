create
    definer = root@localhost procedure afficher_race_selon_espece(IN p_espece_id int)
BEGIN
SELECT id, nom, espece_id, prix
	FROM race
    WHERE espece_id = p_espece_id
    ORDER BY prix ASC;
END;

