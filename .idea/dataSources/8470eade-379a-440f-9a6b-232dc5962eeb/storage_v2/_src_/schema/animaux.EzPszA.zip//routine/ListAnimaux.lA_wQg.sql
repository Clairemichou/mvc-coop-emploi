create
    definer = root@localhost procedure ListAnimaux()
BEGIN
		SELECT animal.id, nom, espece.nom_courant, espece.prix 
    		from animal, espece
    	WHERE animal.espece_id = espece.id;
	END;

