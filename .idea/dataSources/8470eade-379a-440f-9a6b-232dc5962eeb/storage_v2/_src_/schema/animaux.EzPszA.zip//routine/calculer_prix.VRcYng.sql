create
    definer = root@localhost procedure calculer_prix(IN p_race_id int, INOUT p_prix decimal(7, 2))
BEGIN
	SELECT COALESCE(race.prix, espece.prix) + p_prix INTO p_prix
    FROM animal
    JOIN espece ON espece.id = animal.espece_id
    LEFT JOIN race ON race.id = animal.race_id
    WHERE animal.id = p_race_id;
END;

